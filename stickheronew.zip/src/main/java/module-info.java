module com.javafx.game {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;
    requires javafx.graphics;
    requires org.junit.jupiter.api; // Add missing import for JUnit

    opens com.javafx.game to javafx.fxml;

    exports com.javafx.game;
}
